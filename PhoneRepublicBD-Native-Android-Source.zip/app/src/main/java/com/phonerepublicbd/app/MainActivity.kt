package com.phonerepublicbd.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val db=ShopDb(this);setContent{MaterialTheme{App(db)}}}}
@Composable fun App(db:ShopDb){
 var page by remember{mutableStateOf("home")};var refresh by remember{mutableIntStateOf(0)}
 val totals=remember(refresh){db.totals()};val phones=remember(refresh){db.list()}
 Scaffold(topBar={TopAppBar(title={Text("Phone Republic BD")})},bottomBar={NavigationBar{
  listOf("home" to "হোম","add" to "স্টক যোগ","list" to "স্টক").forEach{(k,v)->NavigationBarItem(selected=page==k,onClick={page=k},icon={Text(if(k=="home")"⌂" else if(k=="add")"+" else "▣")},label={Text(v)})}
 }}){pad->Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)){
  when(page){
   "home"->{Text("ব্যবসার সারাংশ",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(12.dp));Metric("বর্তমান ফোন স্টক","${totals.first} টি");Metric("মোট বিক্রয়",money(totals.second));Metric("মোট লাভ",money(totals.third));Text("এই প্রাথমিক সংস্করণে ডেটা এই ফোনে অফলাইনে সংরক্ষিত হয়।")}
   "add"->AddPhone(db){refresh++}
   else->{Text("ফোন স্টক",style=MaterialTheme.typography.titleLarge);LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(phones,key={it.id}){p->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(p.model,style=MaterialTheme.typography.titleMedium);Text("IMEI: ${p.imei}");Text("ক্রয়: ${money(p.buy)} | বিক্রয়: ${money(p.sell)}");Text(if(p.status=="IN_STOCK")"স্টকে আছে" else "বিক্রি হয়েছে");if(p.status=="IN_STOCK")Button(onClick={if(db.sell(p.id))refresh++}){Text("বিক্রি দেখান")}}}}}}
  }
 }}
}
@Composable fun Metric(label:String,value:String){Card(Modifier.fillMaxWidth().padding(bottom=8.dp)){Column(Modifier.padding(16.dp)){Text(label);Text(value,style=MaterialTheme.typography.headlineSmall)}}}
@Composable fun AddPhone(db:ShopDb,changed:()->Unit){
 var model by remember{mutableStateOf("")};var imei by remember{mutableStateOf("")};var buy by remember{mutableStateOf("")};var sell by remember{mutableStateOf("")};var msg by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){
  Text("নতুন ফোন যোগ করুন",style=MaterialTheme.typography.titleLarge)
  OutlinedTextField(model,{model=it},label={Text("ফোনের মডেল")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(imei,{imei=it},label={Text("IMEI নম্বর")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(buy,{buy=it},label={Text("ক্রয়মূল্য (৳)")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(sell,{sell=it},label={Text("বিক্রয়মূল্য (৳)")},modifier=Modifier.fillMaxWidth())
  Button(onClick={val b=buy.toDoubleOrNull();val s=sell.toDoubleOrNull();msg=when{model.isBlank()||imei.isBlank()||b==null||s==null->"সব তথ্য সঠিকভাবে পূরণ করুন";db.add(model,imei,b,s)->{model="";imei="";buy="";sell="";changed();"স্টকে যোগ হয়েছে"};else->"IMEI আগে যোগ করা হয়েছে অথবা তথ্য সংরক্ষণ হয়নি"}},modifier=Modifier.fillMaxWidth()){Text("স্টকে যোগ করুন")}
  Text(msg)
 }
}
fun money(v:Double)="৳"+NumberFormat.getNumberInstance(Locale("en","BD")).format(v)
