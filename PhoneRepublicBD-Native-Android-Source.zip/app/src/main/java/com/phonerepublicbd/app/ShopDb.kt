package com.phonerepublicbd.app
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
data class PhoneItem(val id:Long,val model:String,val imei:String,val buy:Double,val sell:Double,val status:String)
class ShopDb(c:Context):SQLiteOpenHelper(c,"phone_republic.db",null,1){
 override fun onCreate(db:SQLiteDatabase){db.execSQL("CREATE TABLE phones(id INTEGER PRIMARY KEY AUTOINCREMENT,model TEXT NOT NULL,imei TEXT NOT NULL UNIQUE,buy REAL NOT NULL,sell REAL NOT NULL,status TEXT NOT NULL DEFAULT 'IN_STOCK')");db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,phone_id INTEGER NOT NULL,sold_price REAL NOT NULL,sold_at INTEGER NOT NULL)")}
 override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){}
 fun add(model:String,imei:String,buy:Double,sell:Double):Boolean{val v=ContentValues().apply{put("model",model.trim());put("imei",imei.trim());put("buy",buy);put("sell",sell);put("status","IN_STOCK")};return try{writableDatabase.insertOrThrow("phones",null,v);true}catch(_:Exception){false}}
 fun list():List<PhoneItem>{val a=mutableListOf<PhoneItem>();readableDatabase.rawQuery("SELECT id,model,imei,buy,sell,status FROM phones ORDER BY id DESC",null).use{c->while(c.moveToNext())a.add(PhoneItem(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getDouble(4),c.getString(5)))};return a}
 fun sell(id:Long):Boolean{val d=writableDatabase;d.beginTransaction();return try{val v=ContentValues().apply{put("status","SOLD")};if(d.update("phones",v,"id=? AND status='IN_STOCK'",arrayOf(id.toString()))!=1)return false;val p=readableDatabase.rawQuery("SELECT sell FROM phones WHERE id=?",arrayOf(id.toString()));val price= p.use{if(it.moveToFirst())it.getDouble(0) else 0.0};val s=ContentValues().apply{put("phone_id",id);put("sold_price",price);put("sold_at",System.currentTimeMillis())};d.insertOrThrow("sales",null,s);d.setTransactionSuccessful();true}catch(_:Exception){false}finally{d.endTransaction()}}
 fun totals():Triple<Int,Double,Double>{var n=0;var sales=0.0;var profit=0.0;readableDatabase.rawQuery("SELECT COUNT(*) FROM phones WHERE status='IN_STOCK'",null).use{if(it.moveToFirst())n=it.getInt(0)};readableDatabase.rawQuery("SELECT COALESCE(SUM(s.sold_price),0),COALESCE(SUM(s.sold_price-p.buy),0) FROM sales s JOIN phones p ON p.id=s.phone_id",null).use{if(it.moveToFirst()){sales=it.getDouble(0);profit=it.getDouble(1)}};return Triple(n,sales,profit)}
}
